<template>
    <button :class="buttonClass" @click="handleClick" :type="type">
        <slot />
    </button>
</template>

<script>
export default {
    name: "Button",
    props: {
        type: {
            type: String,
            default: 'button'
        },
        variant: {
            type: String,
            default: 'default'
        },
        onClick: {
            type: Function,
            default: () => { }
        }
    },
    computed: {
        buttonClass() {
            const baseClass = 'px-10 py-2 rounded';
            let variantClass = '';

            switch (this.variant) {
                case 'default':
                    variantClass = 'border border-gray-400';
                    break;
                case 'primary':
                    variantClass = 'bg-cyan-500 text-white';
                    break;
                case 'secondary':
                    variantClass = 'bg-gray-500 text-white';
                    break;
                case 'cancel':
                    variantClass = 'bg-white text-black border border-gray-400';
                    break;
                default:
                    break;
            }

            return `${baseClass} ${variantClass}`;
        }
    },
    methods: {
        handleClick() {
            this.onClick();
        }
    }
};
</script>