<template>
  <div>
    <button
      @click="toggleDropdown"
      type="button"
      class="text-2xl text-cyan-500 flex items-center focus:outline-none hover:text-cyan-700"
    >
      <span>Cost details</span>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
        :class="{ 'transform rotate-180 mt-1': isOpen, 'mt-2': !isOpen }"
        class="w-6 h-6 ml-2 transition-transform duration-300"
      >
        <polyline points="6 9 12 15 18 9"></polyline>
      </svg>
    </button>

    <Table v-if="isOpen" />
  </div>
</template>

<script>
import Table from "./Table.vue";

export default {
  components: {
    Table,
  },
  data() {
    return {
      isOpen: true,
    };
  },
  methods: {
    toggleDropdown() {
      this.isOpen = !this.isOpen;
    },
  },
};
</script>
