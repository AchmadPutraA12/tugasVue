<template>
  <div class="bg-gray-100 py-5 fixed bottom-0 w-full">
    <div class="container mx-auto px-4 flex justify-end items-end">
      <Button class="mx-4" variant="cancel" @click="handleCancel">Cancel</Button>
      <Button class="mx-4" variant="default" @click="handleSaveAsDraft">Save as Draft</Button>
      <Button class="mx-4" variant="primary" @click="handleSaveItem">Submit</Button>
    </div>
  </div>
</template>

<script>
import Button from './Button.vue';

export default {
  name: "Footer",
  components: {
    Button,
  },
  methods: {
    handleSaveItem() {
      this.$emit('save-item');
    },
    handleCancel() {
      
    },
    handleSaveAsDraft() {
      
    }
  }
};
</script>
