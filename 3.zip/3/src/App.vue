<template>
  <div id="app">
      <Cost />
  </div>
</template>

<script>
import Cost from '@/views/Cost.vue';

export default {
  name: 'App',
  components: {
      Cost,
  },
};
</script>
