<template>
  <div className="px-7 pt-8 font-normal text-4xl">
    <h1>3rd Party Intruction</h1>
  </div>
  <div className="px-7 py-7">
    <Table />
  </div>
  <Footer @save-item="saveToLocalStorage" />
</template>

<script>
import Table from "@/components/Table.vue";
import Footer from "@/components/Footer.vue";
import { mapGetters } from 'vuex';
import Swal from 'sweetalert2';

export default {
  components: {
    Table,
    Footer,
  },
  computed: {
    ...mapGetters(['items']),
  },
  methods: {
    saveToLocalStorage() {

      localStorage.setItem('items', JSON.stringify(this.items));

      Swal.fire({
        icon: 'success',
        title: 'Item berhasil ditambahkan!',
        text: 'Item baru telah berhasil ditambahkan.',
      });
    },
  },
};
</script>
