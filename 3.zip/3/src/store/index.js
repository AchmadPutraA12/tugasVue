import { createStore } from 'vuex';

const store = createStore({
  state: {
    items: [],
  },
  mutations: {
    setItems(state, items) {
      state.items = items;
    },
    addItem(state, item) {
      state.items.push(item);
    },
    deleteItem(state, itemId) {
      state.items = state.items.filter((item) => item.id !== itemId);
    }
  },
  actions: {
    fetchItems({ commit }) {
      const savedItems = localStorage.getItem('items');
      if (savedItems) {
        const items = JSON.parse(savedItems);
        commit('setItems', items);
      }
    },
    createItem({ commit }, newItem) {
      newItem.id = Date.now();
      commit('addItem', newItem);
      this.dispatch('saveItemsToLocalStorage');
    },
    removeItem({ commit }, itemId) {
      commit('deleteItem', itemId);
      this.dispatch('saveItemsToLocalStorage');
    },
    setItems({ commit }, items) {
      commit('setItems', items);
      this.dispatch('saveItemsToLocalStorage');
    },
    saveItemsToLocalStorage({ state }) {
      localStorage.setItem('items', JSON.stringify(state.items));
    }
  },
  getters: {
    items: (state) => state.items,
  }
});

export default store;
