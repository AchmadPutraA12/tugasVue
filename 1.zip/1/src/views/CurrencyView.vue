<template>
  <div className="px-7 pt-8 font-normal text-4xl">
    <h1>3rd Party Intruction</h1>
  </div>
  <div className="px-7 py-7">
    <Dropdown />
    <Footer @save-item="saveToLocalStorage" />
  </div>
</template>

<script>
import Dropdown from "@/components/Dropdown.vue";
import Footer from "@/components/Footer.vue";
import { mapGetters } from 'vuex';
import Swal from 'sweetalert2';

export default {
  components: {
    Dropdown,
    Footer,
  },
  computed: {
    ...mapGetters(['items']),
  },
  methods: {
    saveToLocalStorage() {

      localStorage.setItem('items', JSON.stringify(this.items));
      
      Swal.fire({
        icon: 'success',
        title: 'Item berhasil ditambahkan!',
        text: 'Item baru telah berhasil ditambahkan.',
      });
    },
  },
};
</script>
