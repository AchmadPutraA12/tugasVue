<template>
  <div class="overflow-x-auto pt-5">
    <table class="min-w-full bg-white border-collapse shadow-md">
      <thead>
        <tr class="text-left bg-gray-100">
          <td class="py-1 px-4">Description</td>
          <td class="py-1 px-4">Qty</td>
          <td class="py-1 px-4">UOM</td>
          <td class="py-1 px-4">Unit Price</td>
          <td class="py-1 px-4">Discount (%)</td>
          <td class="py-3 px-4">VAT (%)</td>
          <td class="py-1 px-4"></td>
          <td class="py-1 px-4">Currency</td>
          <td class="py-1 px-4 text-center">VAT Amount</td>
          <td class="py-1 px-4 text-center">Sub Total</td>
          <td class="py-1 px-4 text-center">Total</td>
          <td class="py-1 px-4">Charge To</td>
          <td class="py-1 px-4"></td>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.id" class="text-left border-b border-gray-200">
          <td class="py-3 px-4">
            <InputTable v-model="item.description" type="text" placeholder="description" />
          </td>
          <td class="py-3 px-4">
            <InputTable v-model.number="item.qty" type="number" placeholder="Qty" />
          </td>
          <td class="py-3 px-4">
            <select v-model="item.uom" class="w-24 h-8 rounded border">
              <option value="SHP">SHP</option>
              <option value="DIY">DIY</option>
              <option value="FRD">FRD</option>
              <option value="PRD">PRD</option>
            </select>
          </td>
          <td class="py-3 px-4">
            <InputTable v-model.number="item.unitPrice" type="number" placeholder="Unit Price" />
          </td>
          <td class="py-3 px-4">
            <InputTable v-model.number="item.discount" type="number" placeholder="0" />
          </td>
          <td class="py-3 px-4">
            <InputTable v-model.number="item.vat" type="number" placeholder="0" />
          </td>
          <td class="py-3 px-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24">
              <path fill="#78716c" d="M4 15V9h8V4.16L19.84 12L12 19.84V15z" />
            </svg>
          </td>
          <td class="py-3 px-4">
            <select v-model="item.currency" class="w-24 h-8 rounded border">
              <option value="USD">USD</option>
              <option value="AED">AED</option>
            </select>
          </td>
          <td class="py-3 px-4 text-center">
            {{ calculateVATAmount(item).toFixed(2) }}
          </td>
          <td class="py-3 px-4 text-center">
            {{ calculateItemSubtotal(item).toFixed(2) }}
          </td>
          <td class="py-3 px-4 text-center">
            {{ calculateItemTotal(item).toFixed(2) }}
          </td>
          <td class="py-3 px-4">
            <select v-model="item.chargeTo" class="w-36 h-8 rounded border">
              <option value="Lorem" selected>Lorem Ipsum</option>
              <option value="Dolor">Dolor sit amet</option>
            </select>
          </td>
          <td class="py-3 px-4">
            <button @click="handleDelete(item.id)">
              <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 24 24"
                class="bg-cyan-500 rounded">
                <path fill="white" d="M19 12.998H5v-2h14z" />
              </svg>
            </button>
          </td>
        </tr>

        <tr>
          <td class="py-3 px-4" rowspan="2" colspan="7">
            Exchange Rate 1 USD =
            <InputTable v-model.number="exchangeRate" type="number" placeholder="0" />
            <span class="ml-5">AED</span>
          </td>
          <td class="py-3 px-4">AED in Total</td>
          <td class="py-3 px-4 text-center">0.00</td>
          <td class="py-3 px-4 text-center">{{ calculateTotalByCurrency('AED').toFixed(2) }}</td>
          <td class="py-3 px-4 text-center">{{ calculateTotalByCurrency('AED').toFixed(2) }}</td>
          <td rowspan="2"></td>
          <td rowspan="2" class="py-3 px-4">
            <button @click="handleAddItem">
              <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 24 24"
                class="bg-cyan-500 rounded">
                <path fill="white" d="M19 12.998h-6v6h-2v-6H5v-2h6v-6h2v6h6z" />
              </svg>
            </button>
          </td>
        </tr>
        <tr>
          <td class="py-3 px-4">USD in Total</td>
          <td class="py-3 px-4 text-center">0.00</td>
          <td class="py-3 px-4 text-center">{{ calculateTotalByCurrency('USD').toFixed(2) }}</td>
          <td class="py-3 px-4 text-center">{{ calculateTotalByCurrency('USD').toFixed(2) }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import Swal from 'sweetalert2';
import { mapGetters, mapActions } from 'vuex';
import InputTable from "./InputTable.vue";

export default {
  components: {
    InputTable,
  },
  data() {
    return {
      exchangeRate: 0,
    };
  },
  computed: {
    ...mapGetters(['items']),

    totalUSD() {
      return this.items.reduce((total, item) => total + this.calculateItemSubtotal(item), 0);
    },

    totalVAT() {
      return this.items.reduce((total, item) => total + this.calculateVATAmount(item), 0);
    },

    totalAED() {
      if (this.exchangeRate) {
        return this.totalUSD * this.exchangeRate;
      }
      return 0;
    },
  },
  methods: {
    ...mapActions(['createItem', 'removeItem', 'setItems']),

    handleAddItem() {
      const newItem = {
        id: Date.now(),
        description: '',
        qty: 0,
        uom: 'SHP',
        unitPrice: 0,
        discount: 0,
        vat: 0,
        currency: 'USD',
        chargeTo: 'Lorem Ipsum',
      };
      this.createItem(newItem);
    },

    handleDelete(itemId) {
      if (this.items.length <= 1) {
        Swal.fire({
          icon: 'warning',
          title: 'Tidak dapat menghapus',
          text: 'Tidak dapat menghapus item, karena hanya ada satu item yang tersisa.',
        });
        return;
      }

      this.setItems(this.items.filter(item => item.id !== itemId));

      Swal.fire({
        icon: 'success',
        title: 'Sukses',
        text: 'Item berhasil dihapus!',
      });
    },

    calculateItemTotal(item) {
      const subtotal = this.calculateItemSubtotal(item);
      const vatAmount = this.calculateVATAmount(item);

      let total = subtotal + vatAmount;

      return total;
    },

    calculateItemSubtotal(item) {

      const discountAmount = (item.discount / 100) * (item.qty * item.unitPrice);
      let subtotal = (item.qty * item.unitPrice) - discountAmount;

      if (item.currency === 'AED') {
        const rate = this.exchangeRate === 0 ? 1 : this.exchangeRate;
        subtotal *= rate;
      }

      return subtotal;
    },

    calculateTotalByCurrency(currency) {
      let total = 0;
      for (const item of this.items) {
        if (item.currency === currency) {
          total += this.calculateItemSubtotal(item);
        }
      }
      return total;
    },

    calculateVATAmount(item) {
      return (item.vat / 100) * this.calculateItemSubtotal(item);
    },

    saveToLocalStorage() {
      localStorage.setItem('items', JSON.stringify(this.items));
    },

    loadFromLocalStorage() {
      const savedItems = localStorage.getItem('items');
      if (savedItems) {
        const items = JSON.parse(savedItems);
        this.setItems(items);
      }
    },
  },
  created() {
    this.loadFromLocalStorage();
  },
};
</script>
