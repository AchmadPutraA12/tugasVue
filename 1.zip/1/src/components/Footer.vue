<template>
  <div class="bg-gray-100 py-5 fixed bottom-0 w-full">
    <div class="container mx-auto px-4 flex justify-end items-end">
      <button class="px-10 py-2">Cancel</button>
      <button class="mx-5 px-10 py-2 border border-gray-400 rounded">
        Save as Draft
      </button>
      <button @click="handleSaveItem" class="mx-5 px-10 py-2 bg-cyan-500 text-white rounded">
        submit
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: "Footer",
  methods: {
    handleSaveItem() {
      this.$emit('save-item');
    }
  }
};
</script>
